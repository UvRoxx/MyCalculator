package com.example.userform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
public int i=0,k=0,val1,val2,result=0;
    public TextView textViewOutput;
    public String input,operator,show="";
    public Button button1,button2,button3,button4,button5,button6,button7,button8,button9,buttonZero,buttonAdd,buttonSub,buttonMul,buttonDiv,buttonAns,buttonAc;
    //These are all the global variables i have used here for data handling.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inatialize();



    }



    private void inatialize() {
        textViewOutput=findViewById(R.id.textViewOutput);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button8=findViewById(R.id.button8);
        button9=findViewById(R.id.button9);
        buttonZero=findViewById(R.id.buttonZero);
        buttonAdd=findViewById(R.id.buttonAdd);
        buttonSub=findViewById(R.id.buttonSub);
        buttonMul=findViewById(R.id.buttonMul);
        buttonDiv=findViewById(R.id.buttonDiv);
        buttonAc=findViewById(R.id.buttonAc);
        buttonAns=findViewById(R.id.buttonAns);
//Here i initialize all the button using findViewById.
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonZero.setOnClickListener(this);
        buttonAdd.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonAns.setOnClickListener(this);
        buttonAc.setOnClickListener(this);

//This is the onclick listener for each and every button on the app.
        }


    @Override
    public void onClick(View v) {

        int id= v.getId();
        switch (id){

            case R.id.button1:
               show(1);//For printing the numbers on the textview i create a simple function show to handle all the operations  and then just print the output.
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button2:
                show(2);
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button3:
                show(3);
                textViewOutput.setText(""+show+result);
                break;

            case R.id.button4:
                show(4);
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button5:
               show(5);
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button6:
               show(6);
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button7:
                show(7);

                textViewOutput.setText(""+show+result);
                break;
            case R.id.button8:
                show(8);
                textViewOutput.setText(""+show+result);
                break;
            case R.id.button9:
               show(9);
                textViewOutput.setText(""+show+result);
                break;

            case R.id.buttonZero:
            show(0);
                textViewOutput.setText(""+show+result);
                break;
            //For accepting the operator i placed the case within the same case but i create a second data variable for string to hold the values.


            case R.id.buttonSub:
                operator="-";
                val1=result;
                result=0;
                textViewOutput.setText(""+result+operator);
                show=(result+operator);
                k=1;
                break;
            case R.id.buttonAdd:
                operator="+";
                val1=result;
                textViewOutput.setText(""+result+operator);
                show=(result+operator);
                result=0;
                k=1;
                break;
            case R.id.buttonMul:
                operator="*";
                val1=result;
                textViewOutput.setText(""+result+operator);
                show=(result+operator);
                result=0;
                k=1;
                break;
            case R.id.buttonDiv:
                operator="/";
                val1=result;
                textViewOutput.setText(""+result+operator);
                show=(result+operator);
                result=0;

                k=1;
                break;
            case R.id.buttonAc:
                i=0;
                result=0;
                k=0;
                show="";
                operator="";
                textViewOutput.setText(" ");
                break;

            case R.id.buttonAns:
                if(k==1)
                {
                    val2=result;
                    textViewOutput.setText(" ");
                {
                    switch(operator)
                    {
                        case "+":
                            result=val1+val2;
                            textViewOutput.setText(""+result);
                            break;
                        case "-":
                            result=val1-val2;
                            textViewOutput.setText(""+result);
                            break;
                        case "*":
                            result=val1*val2;
                            textViewOutput.setText(""+result);
                            break;
                        case"/":
                            result=val1/val2;
                            textViewOutput.setText(""+result);
                            break;


                    }
                    val1=result;
                    //result=0;
                    i=0;

                }


            }
                else{
                    textViewOutput.setText("ERROR Press A.C");//The error handling part is still a little more in development but for now the A.C button resolves mostly common issues.
                }

                }
                }







    private void reset() {
        i=0;

    }



    private void show(int a) {
        if (textViewOutput.getText().toString() == null) {
            result = a;
k=1;
            i++;

        } else
            {
            result = result * 10 + (a);
k=1;
        }


    }


}